import React from "react";

export default function Widget(props: { rows: number, cols: number, children?: React.ReactNode }) {
    const style = {gridRowEnd: `span ${props.rows}`, gridColumnEnd: `span ${props.cols}`};
    return <article data-cols={props.cols} data-rows={props.rows} style={style}>{props.children}</article>;
}
