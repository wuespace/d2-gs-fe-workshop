import React, {useEffect, useState} from "react";
import './ContentArea.scss';
import {CircleMarker, Map, TileLayer} from 'react-leaflet';
import Widget from "./Widget";
import {CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis} from "recharts";

export default function ContentArea() {
    const [data, setData] = useState([{x: 0, y: 1}, {x: 1, y: 6}]);

    useEffect(() => {
        let interval = setInterval(() => {
            setData([...data, {x: data.length, y: data.length * data.length}]);
        }, 100);

        return () => clearInterval(interval);
    }, [data])

    const [log, setLog] = useState<string[]>([]);

    useEffect(() => {
        let interval = setInterval(() => {
            console.log([...log, (new Date()).toLocaleTimeString() + ': Lorem Ipsum'])
            setLog([...log, (new Date()).toLocaleTimeString() + ': Lorem Ipsum'])
        }, 3000);

        return () => clearInterval(interval);
    }, [log])

    return <div className="Content">
        <Widget cols={2} rows={2}>
            <Map style={{height: '100%'}} center={[49.785019, 9.974702]} zoom={6}>
                <TileLayer
                    attribution='&copy; <a href="https://stadiamaps.com/">Stadia Maps</a>, &copy; <a href="https://openmaptiles.org/">OpenMapTiles</a> &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors'
                    url="https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}{r}.png"
                />
                <CircleMarker center={[49.785019, 9.974702]} radius={10}/>
            </Map>
        </Widget>
        <Widget cols={1} rows={2}>
            <div className={'padding'} style={{width: '100%', height: '100%'}}>
                <ResponsiveContainer>
                    <LineChart data={data} margin={{top: 5, right: 20, bottom: 5, left: 0}}>
                        <Line dot={false} isAnimationActive={false} dataKey={'y'}/>
                        <CartesianGrid stroke="#ccc" strokeDasharray="5 5"/>
                        <XAxis dataKey={'x'} stroke={'white'}/>
                        <YAxis dataKey={'y'} stroke={'white'}/>
                        <Tooltip isUpdateAnimationActive={true} active={true}/>
                    </LineChart>
                </ResponsiveContainer>
            </div>
        </Widget>
        <Widget cols={1} rows={4}>
            <main>
                <div className="padding">
                    <h2>Event Log</h2>
                    <pre>{log.join('\n')}</pre>
                </div>
            </main>
        </Widget>
        <Widget cols={1} rows={1}/>
        <Widget cols={1} rows={2}/>
        <Widget cols={1} rows={2}/>
        <Widget cols={1} rows={1}/>
    </div>;
}
