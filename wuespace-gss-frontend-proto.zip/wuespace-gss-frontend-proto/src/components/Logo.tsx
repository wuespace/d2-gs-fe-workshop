import logo from "../media/logo.svg";
import React from "react";

export default function Logo() {
    return <img src={logo} alt="Logo"/>;
}
