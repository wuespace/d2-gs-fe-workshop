import React from 'react';
import './App.scss';
import Header from "./Header";
import ContentArea from "./ContentArea/ContentArea";

import 'leaflet/dist/leaflet.css'
import 'leaflet/dist/leaflet.js'

function App() {
  return (
      <div className="grid-container">
          <Header/>
          <ContentArea/>
      </div>
  );
}

export default App;
