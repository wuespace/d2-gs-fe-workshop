import React from "react";
import './Header.scss';
import Logo from "./Logo";
import WorkspaceSelector from "./WorkspaceSelector";
import StatusIndicator from "./StatusIndicator";

export default function Header() {
    return <div className="Header">
        <Logo/>
        <WorkspaceSelector/>
        <StatusIndicator/>
    </div>;
}
