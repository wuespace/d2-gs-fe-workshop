import status from "../media/status.svg";
import React from "react";

export default function StatusIndicator() {
    return <img src={status} alt="Status indicator"/>;
}
