import workspaceSelector from "../media/workspace-selector.svg";
import React from "react";

export default function WorkspaceSelector() {
    return <img src={workspaceSelector} alt="Workspace selector"/>;
}
